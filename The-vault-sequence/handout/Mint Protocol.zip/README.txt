The Mint Protocol

Recovered from: internal-ca.mint.local
Incident Tag: MP-01

Analyze the certificates and reconstruct what was left behind.
